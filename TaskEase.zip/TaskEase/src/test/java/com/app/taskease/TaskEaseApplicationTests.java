package com.app.taskease;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskEaseApplicationTests {

	@Test
	void contextLoads() {
	}

}
