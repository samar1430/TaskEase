package com.app.taskease.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.taskease.model.Profession;
import com.app.taskease.model.User;
import com.app.taskease.repository.AdminRepository;

@Service
public class AdminServiceImpl {

	@Autowired 
	private AdminRepository adminRepository;
	
	public List<Profession> getAllProfession(){
		
		return adminRepository.findAll();
	}

	public void delete(int id) {
		adminRepository.deleteById(id);		
	}
}
