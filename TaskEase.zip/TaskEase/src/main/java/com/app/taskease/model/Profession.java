package com.app.taskease.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Profession {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String fullName;
	private String mobile;
	private String email;
	private String type;
	private String password;
	private String confirm_password;

	public Profession() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Profession(int id, String fullName, String type, String email, String mobile, String password,
			String confirm_password) {
		super();
		this.id = id;
		this.fullName = fullName;
		this.type = type;
		this.email = email;
		this.mobile = mobile;
		this.password = password;
		this.confirm_password = confirm_password;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFullName() {
		return fullName;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfirm_password() {
		return confirm_password;
	}

	public void setConfirm_password(String confirm_password) {
		this.confirm_password = confirm_password;
	}

	@Override
	public String toString() {
		return "Profession [id=" + id + ", fullName=" + fullName + ", type=" + type + ", email=" + email + ", mobile="
				+ mobile + ", password=" + password + ", confirm_password=" + confirm_password + "]";
	}

}
