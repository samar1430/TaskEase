package com.app.taskease.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.taskease.model.Admin;
import com.app.taskease.model.Profession;
import com.app.taskease.model.User;

public interface AdminRepository extends JpaRepository<Profession, Integer>{

	
}
