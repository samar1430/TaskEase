package com.app.taskease.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.app.taskease.model.Profession;
import com.app.taskease.model.User;
import com.app.taskease.service.UserServiceImpl;

import jakarta.servlet.http.HttpSession;

@Controller
public class UserController {

	@Autowired
	private UserServiceImpl userServiceImpl;

	@GetMapping("/userRegister")
	public String userRegister() {
		return "userRegister";
	}

	@GetMapping("/userLogin")
	public String userLogin() {
		return "userLogin";
	}

	@PostMapping("/createUser")
	public String addUser(@ModelAttribute User user,Model model) {

		boolean b=userServiceImpl.checkEmail(user.getEmail());
		if(b) {
			 model.addAttribute("condition",true);
			return "userRegister";
		}
		model.addAttribute("condition",false);
		userServiceImpl.adduser(user);
		return "userRegister";
	}

	@PostMapping("/userConfirm")
	public String userConfirm(@ModelAttribute User user,Model model) {

		boolean b = userServiceImpl.checkUser(user);
		if (b) {
			return "demo2";
		}
		model.addAttribute("checked",true);
		return "userLogin";
	}

	@GetMapping("/goto/{profession}")
	public String listOfpro(@PathVariable String profession, Model model) {

		List<Profession> findPro = userServiceImpl.findPro(profession);
		model.addAttribute("list", findPro);
		return "userChoice";
	}
}
