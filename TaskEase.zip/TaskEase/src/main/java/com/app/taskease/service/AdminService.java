package com.app.taskease.service;

public interface AdminService {

}
