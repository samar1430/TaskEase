package com.app.taskease.service;

import com.app.taskease.model.Profession;

public interface ProfessionService {

	public void addProfession(Profession profession);

	public boolean checkEmail(String email);

	public boolean proConfirm(Profession profession);
}
