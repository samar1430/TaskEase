package com.app.taskease.service;

import java.util.List;

import com.app.taskease.model.Profession;
import com.app.taskease.model.User;

public interface UserService {
	public void adduser(User user);

	public boolean checkUser(User user);

	public List<Profession> findPro(String profession);

	public boolean checkEmail(String email);

}
