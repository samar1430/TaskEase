package com.app.taskease.controller;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.app.taskease.model.Profession;
import com.app.taskease.service.ProfessionServiceImpl;

@Controller
public class ProfessionalController {

	@Autowired 
	private ProfessionServiceImpl professionServiceImpl;
	@GetMapping("/professionalRegister")
	public String professionalRegister() 
	{
		return "professionalRegister";
	}
	
	@GetMapping("/proLogin")
	public String proLogin() {
		return "proLogin";
	}
	
	@PostMapping("/createProfession")
	public String addProfession(@ModelAttribute Profession profession,Model model) {
	
//		System.out.println(profession);
		boolean b=professionServiceImpl.checkEmail(profession.getEmail());
		if(b){
			model.addAttribute("condition",true);
			return "professionalRegister";
		}
		
		model.addAttribute("condition",false);
		professionServiceImpl.addProfession(profession);
		return "professionalRegister";
	}
	
	@PostMapping("/proConfirm")
	public String checkPro(@ModelAttribute Profession profession,Model model) {
			boolean b = professionServiceImpl.proConfirm(profession);
			System.out.println(b+" controller");
			if(b){				
				return "visitedUsers";
			}
			model.addAttribute("b",true);
			return "proLogin";
		
	}
	
	
}
