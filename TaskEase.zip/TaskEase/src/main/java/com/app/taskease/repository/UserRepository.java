package com.app.taskease.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.taskease.model.User;

public interface UserRepository extends JpaRepository<User, Integer> {

	public User findByEmailAndPassword(String email, String password);

	public boolean existsByEmail(String email);

}
