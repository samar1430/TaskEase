package com.app.taskease.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.taskease.model.Profession;
import com.app.taskease.model.User;
import com.app.taskease.repository.ProfessionRepository;
import com.app.taskease.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	public ProfessionRepository professionRepository;

	public void adduser(User user) {
		userRepository.save(user);
		System.out.println(user);
	}

	public boolean checkUser(User user) {
		String email = user.getEmail();
		String password = user.getPassword();
		User emailAndPassword = userRepository.findByEmailAndPassword(email, password);
		if (emailAndPassword == null) {
			return false;
		}
		if (emailAndPassword.getEmail().equals(email) && emailAndPassword.getPassword().equals(password)) {
			return true;
		}
		return false;
	}

	public List<Profession> findPro(String profession) {
		List<Profession> findByProfession = professionRepository.findByType(profession);
		return findByProfession;

	}

	public boolean checkEmail(String email) {
		boolean b=userRepository.existsByEmail(email);
		System.out.println(b);
		if(b) {
			return true;
		}
		return false;
	}

}
