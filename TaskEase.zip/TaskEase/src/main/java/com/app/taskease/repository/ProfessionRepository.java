package com.app.taskease.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.app.taskease.model.Profession;

public interface ProfessionRepository extends JpaRepository<Profession, Integer> {

	 public List<Profession> findByType(String profession);

	public boolean existsByEmail(String email);

	public Profession findByEmailAndPassword(String email, String password);

}
