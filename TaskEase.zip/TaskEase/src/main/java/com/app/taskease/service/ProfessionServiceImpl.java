package com.app.taskease.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.taskease.model.Profession;
import com.app.taskease.repository.ProfessionRepository;

@Service
public class ProfessionServiceImpl {

	@Autowired
	private ProfessionRepository professionRepository;

	public void addProfession(Profession profession) {

		professionRepository.save(profession);
		System.out.println(profession);

	}

	public boolean checkEmail(String email) {
		boolean b = professionRepository.existsByEmail(email);
		System.out.println(b);
		if (b) {
			return true;
		}
		return false;
	}

	public boolean proConfirm(Profession profession) {
		String email=profession.getEmail();
		String password=profession.getPassword();
		
		Profession emailAndPassword = professionRepository.findByEmailAndPassword(email, password);
		if(emailAndPassword==null) {
			return false;
		}
		if(emailAndPassword.getEmail().equals(email) && emailAndPassword.getPassword().equals(password)) {
			return true;
		}
		return false;
		
	}
}




















