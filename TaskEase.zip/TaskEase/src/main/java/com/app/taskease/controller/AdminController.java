package com.app.taskease.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.app.taskease.model.Admin;
import com.app.taskease.model.Profession;
import com.app.taskease.model.User;
import com.app.taskease.service.AdminServiceImpl;

@Controller
public class AdminController {
	@Autowired
	private AdminServiceImpl adminServiceImpl;

	@GetMapping("/")
	public String index() {

		return "index";
	}

	@GetMapping("/adminLogin")
	public String adminLogin() {

		return "adminLogin";
	}

	@PostMapping("/adminConfirm")
	public String adminConfirm(@ModelAttribute Admin admin,Model model) {
//		System.out.println(admin);

		if (admin.getUsername().equals("admin") && admin.getPassword().equals("password")) {
			return "redirect:/proList";
		}
		model.addAttribute("checked",true);
		return "adminLogin";
	}

	@GetMapping("/proList")
	public String professionList(Model model) {
		List<Profession> allProfession = adminServiceImpl.getAllProfession();
		model.addAttribute("pro", allProfession);
		return "proList";
	}

	@GetMapping("/delete/{id}")
	public String delete(@PathVariable int id) {
		adminServiceImpl.delete(id);
		return "redirect:/proList";
	}

}
